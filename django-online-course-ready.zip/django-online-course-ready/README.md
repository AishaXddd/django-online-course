# Django Online Course Ready Project

IBM/Coursera-style final project implementation.

## Run on Windows

```text
python -m venv venv
venv\Scripts\activate
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo
python manage.py createsuperuser
python manage.py runserver
```

Open `http://127.0.0.1:8000/admin/` for the admin screenshot and `http://127.0.0.1:8000/course/1/` for the course/mock exam.
