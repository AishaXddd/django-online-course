from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404,redirect,render
from .models import Choice,Course,Question,Submission
def course_details(request,course_id):
    course=get_object_or_404(Course,id=course_id)
    return render(request,'onlinecourse/course_details_bootstrap.html',{'course':course})
def exam(request,course_id):
    course=get_object_or_404(Course,id=course_id)
    return render(request,'onlinecourse/exam.html',{'course':course})
def submit(request,course_id):
    course=get_object_or_404(Course,id=course_id)
    if request.method!='POST': return redirect('exam',course_id=course.id)
    user=request.user
    if not user.is_authenticated: user,_=User.objects.get_or_create(username='demo_student')
    questions=Question.objects.filter(lesson__course=course)
    Submission.objects.filter(user=user,question__in=questions).delete()
    for question in questions:
        choice_id=request.POST.get(f'question_{question.id}')
        if choice_id:
            try: choice=Choice.objects.get(id=choice_id,question=question)
            except Choice.DoesNotExist: continue
            Submission.objects.create(user=user,question=question,selected_choice=choice)
    return redirect('show_exam_result',course_id=course.id)
def show_exam_result(request,course_id):
    course=get_object_or_404(Course,id=course_id)
    user=request.user
    if not user.is_authenticated: user,_=User.objects.get_or_create(username='demo_student')
    questions=Question.objects.filter(lesson__course=course)
    submissions=Submission.objects.filter(user=user,question__in=questions).select_related('question','selected_choice')
    score=sum(1 for s in submissions if s.selected_choice.is_correct)
    return render(request,'onlinecourse/exam_result.html',{'course':course,'score':score,'total':questions.count(),'submissions':submissions})
