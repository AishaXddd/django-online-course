from django.core.management.base import BaseCommand
from onlinecourse.models import Course,Lesson,Question,Choice
class Command(BaseCommand):
    def handle(self,*args,**kwargs):
        course,_=Course.objects.get_or_create(id=1,defaults={'name':'Python Programming','description':'A beginner-friendly Python programming course.'})
        course.name='Python Programming'; course.description='A beginner-friendly Python programming course.'; course.save()
        lesson,_=Lesson.objects.get_or_create(id=1,defaults={'course':course,'name':'Python Basics','description':'Variables, functions and basic Python concepts.'})
        lesson.course=course; lesson.name='Python Basics'; lesson.description='Variables, functions and basic Python concepts.'; lesson.save()
        data=[('Which keyword is used to define a function in Python?',['def','function','func','define'],0),('Which language is Django based on?',['Java','Python','C++','Ruby'],1),('Which symbol starts a Python comment?',['//','#','<!--','**'],1)]
        for text,choices,correct in data:
            q,_=Question.objects.get_or_create(lesson=lesson,question_text=text); q.choices.all().delete()
            for i,c in enumerate(choices): Choice.objects.create(question=q,choice_text=c,is_correct=i==correct)
        self.stdout.write(self.style.SUCCESS('Demo data ready. Open http://127.0.0.1:8000/course/1/'))
